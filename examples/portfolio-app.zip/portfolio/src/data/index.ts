import type {
  PersonalInfo,
  SocialLink,
  SkillCategory,
  Project,
  Experience,
  NavItem,
} from "../types";

// ─── Personal Info ─────────────────────────────────────────────────────────────
export const personalInfo: PersonalInfo = {
  name: "Alex Mercer",
  role: "Full-Stack Engineer",
  tagline: "I craft elegant digital experiences that live at the intersection of design and technology.",
  bio: "A full-stack engineer with 6+ years of experience building scalable web applications. I specialize in React ecosystems and Node.js backends, with a keen eye for UX and performance optimization. I believe the best code is both technically excellent and human-centered.",
  location: "San Francisco, CA",
  email: "alex@mercerdev.io",
  phone: "+1 (415) 555-0192",
  avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=Alex&backgroundColor=d4a840&radius=50",
  resumeUrl: "/resume.pdf",
};

// ─── Navigation ────────────────────────────────────────────────────────────────
export const navItems: NavItem[] = [
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Experience", href: "#experience" },
  { label: "Contact", href: "#contact" },
];

// ─── Social Links ──────────────────────────────────────────────────────────────
export const socialLinks: SocialLink[] = [
  { platform: "GitHub", url: "https://github.com/alexmercer", icon: "github" },
  { platform: "LinkedIn", url: "https://linkedin.com/in/alexmercer", icon: "linkedin" },
  { platform: "Twitter", url: "https://twitter.com/alexmercer", icon: "twitter" },
  { platform: "Email", url: "mailto:alex@mercerdev.io", icon: "mail" },
];

// ─── Skills ────────────────────────────────────────────────────────────────────
export const skillCategories: SkillCategory[] = [
  {
    id: "frontend",
    label: "Frontend",
    icon: "monitor",
    skills: [
      { name: "React / Next.js", level: 95 },
      { name: "TypeScript", level: 90 },
      { name: "Tailwind CSS", level: 92 },
      { name: "Framer Motion", level: 80 },
      { name: "GraphQL", level: 75 },
    ],
  },
  {
    id: "backend",
    label: "Backend",
    icon: "server",
    skills: [
      { name: "Node.js", level: 88 },
      { name: "Python / FastAPI", level: 78 },
      { name: "PostgreSQL", level: 82 },
      { name: "Redis", level: 70 },
      { name: "REST APIs", level: 93 },
    ],
  },
  {
    id: "devops",
    label: "DevOps & Cloud",
    icon: "cloud",
    skills: [
      { name: "AWS", level: 75 },
      { name: "Docker / K8s", level: 72 },
      { name: "CI/CD (GitHub Actions)", level: 85 },
      { name: "Vercel / Netlify", level: 90 },
      { name: "Linux", level: 78 },
    ],
  },
  {
    id: "tools",
    label: "Tools & Craft",
    icon: "wrench",
    skills: [
      { name: "Git", level: 95 },
      { name: "Figma", level: 70 },
      { name: "Jest / Vitest", level: 83 },
      { name: "Storybook", level: 72 },
      { name: "Webpack / Vite", level: 80 },
    ],
  },
];

// ─── Projects ──────────────────────────────────────────────────────────────────
export const projects: Project[] = [
  {
    id: "proj-1",
    title: "Obsidian — Design System",
    description: "A comprehensive design system and component library powering 3 enterprise SaaS products. Built with React, TypeScript, and Storybook.",
    techStack: ["React", "TypeScript", "Storybook", "Rollup", "Chromatic"],
    githubUrl: "https://github.com/alexmercer/obsidian-ds",
    liveUrl: "https://obsidian.mercerdev.io",
    featured: true,
    year: 2024,
  },
  {
    id: "proj-2",
    title: "Fluxboard — Analytics Dashboard",
    description: "Real-time analytics dashboard with live WebSocket data feeds, customizable widgets, and advanced chart types. Handles 100K+ data points smoothly.",
    techStack: ["Next.js", "D3.js", "WebSockets", "PostgreSQL", "Redis"],
    githubUrl: "https://github.com/alexmercer/fluxboard",
    liveUrl: "https://fluxboard.io",
    featured: true,
    year: 2024,
  },
  {
    id: "proj-3",
    title: "Meridian — API Gateway",
    description: "High-performance API gateway with rate limiting, JWT auth, request transformation, and a visual dashboard for monitoring.",
    techStack: ["Node.js", "Fastify", "Redis", "Docker", "Prometheus"],
    githubUrl: "https://github.com/alexmercer/meridian",
    featured: true,
    year: 2023,
  },
  {
    id: "proj-4",
    title: "Journo — Writing App",
    description: "Minimal, distraction-free writing environment with AI-powered suggestions, version history, and multi-format export.",
    techStack: ["React", "Electron", "OpenAI API", "SQLite"],
    githubUrl: "https://github.com/alexmercer/journo",
    liveUrl: "https://journo.app",
    featured: false,
    year: 2023,
  },
  {
    id: "proj-5",
    title: "Cairn — CLI Task Manager",
    description: "A fast, keyboard-driven CLI task manager with project workspaces, time tracking, and GitHub Issues sync.",
    techStack: ["Python", "Typer", "SQLite", "Rich"],
    githubUrl: "https://github.com/alexmercer/cairn",
    featured: false,
    year: 2022,
  },
];

// ─── Experience ────────────────────────────────────────────────────────────────
export const experiences: Experience[] = [
  {
    id: "exp-1",
    type: "work",
    title: "Senior Frontend Engineer",
    organization: "Linear",
    location: "San Francisco, CA (Remote)",
    startDate: "Jan 2023",
    endDate: "Present",
    description: [
      "Lead frontend architecture for core product, improving performance by 40% through strategic code-splitting and React Query optimization.",
      "Built and maintained a shared component library used across 4 product teams.",
      "Mentored 3 junior engineers; introduced architectural review process now adopted org-wide.",
    ],
    technologies: ["React", "TypeScript", "GraphQL", "Radix UI"],
  },
  {
    id: "exp-2",
    type: "work",
    title: "Full-Stack Engineer",
    organization: "Vercel",
    location: "Remote",
    startDate: "Mar 2021",
    endDate: "Dec 2022",
    description: [
      "Contributed to Next.js framework core — implemented several RSC-related features during early beta.",
      "Built internal tooling that reduced deployment debugging time by 60%.",
      "Collaborated cross-functionally with design and infrastructure teams on Edge Functions launch.",
    ],
    technologies: ["Next.js", "Go", "PostgreSQL", "Node.js"],
  },
  {
    id: "exp-3",
    type: "work",
    title: "Frontend Developer",
    organization: "Figma",
    location: "San Francisco, CA",
    startDate: "Jun 2019",
    endDate: "Feb 2021",
    description: [
      "Worked on the multiplayer canvas rendering engine, optimizing performance for large documents.",
      "Built the plugin developer SDK and documentation infrastructure.",
    ],
    technologies: ["TypeScript", "WebGL", "Rust (WASM)", "React"],
  },
  {
    id: "edu-1",
    type: "education",
    title: "B.S. Computer Science",
    organization: "UC Berkeley",
    location: "Berkeley, CA",
    startDate: "Aug 2015",
    endDate: "May 2019",
    description: [
      "Graduated with Honors. Focus on HCI and Distributed Systems.",
      "Teaching Assistant for CS61B (Data Structures) for 3 semesters.",
    ],
  },
];
