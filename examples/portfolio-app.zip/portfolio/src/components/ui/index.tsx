import React from "react";

// ─── Button ────────────────────────────────────────────────────────────────────
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "outline" | "ghost";
  size?: "sm" | "md" | "lg";
  as?: "button" | "a";
  href?: string;
  children: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  variant = "primary",
  size = "md",
  as: Tag = "button",
  href,
  children,
  className = "",
  ...props
}) => {
  const base =
    "inline-flex items-center gap-2 font-sans font-medium tracking-wide transition-all duration-200 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--gold)] focus-visible:ring-offset-2";

  const variants = {
    primary:
      "bg-[var(--text)] text-[var(--bg)] hover:bg-[var(--gold)] hover:text-[var(--bg)]",
    outline:
      "border border-[var(--text)] text-[var(--text)] hover:bg-[var(--text)] hover:text-[var(--bg)]",
    ghost:
      "text-[var(--text-muted)] hover:text-[var(--text)] hover:bg-[var(--bg-alt)]",
  };

  const sizes = {
    sm: "px-4 py-1.5 text-sm",
    md: "px-6 py-2.5 text-sm",
    lg: "px-8 py-3.5 text-base",
  };

  const classes = `${base} ${variants[variant]} ${sizes[size]} ${className}`;

  if (Tag === "a") {
    return (
      <a href={href} className={classes} target="_blank" rel="noopener noreferrer">
        {children}
      </a>
    );
  }

  return (
    <button className={classes} {...props}>
      {children}
    </button>
  );
};

// ─── Badge ─────────────────────────────────────────────────────────────────────
interface BadgeProps {
  children: React.ReactNode;
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({ children, className = "" }) => (
  <span
    className={`inline-block px-2.5 py-0.5 text-xs font-mono font-medium tracking-wider 
    bg-[var(--bg-alt)] text-[var(--text-muted)] border border-[var(--border)] ${className}`}
  >
    {children}
  </span>
);

// ─── SectionHeader ─────────────────────────────────────────────────────────────
interface SectionHeaderProps {
  number: string;
  title: string;
  subtitle?: string;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({
  number,
  title,
  subtitle,
}) => (
  <div className="mb-12 md:mb-16">
    <span className="font-mono text-xs tracking-[0.25em] uppercase text-[var(--gold)] mb-3 block">
      {number}
    </span>
    <h2
      className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-[var(--text)] leading-tight"
      style={{ fontFamily: "'Playfair Display', serif" }}
    >
      {title}
    </h2>
    {subtitle && (
      <p className="mt-4 text-[var(--text-muted)] max-w-xl leading-relaxed">
        {subtitle}
      </p>
    )}
    <div className="w-16 h-px bg-[var(--gold)] mt-5" />
  </div>
);

// ─── Card ──────────────────────────────────────────────────────────────────────
interface CardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
}

export const Card: React.FC<CardProps> = ({
  children,
  className = "",
  hover = true,
}) => (
  <div
    className={`bg-[var(--bg-alt)] border border-[var(--border)] p-6 
    ${hover ? "hover:border-[var(--gold)] hover:shadow-lg transition-all duration-300" : ""} 
    ${className}`}
  >
    {children}
  </div>
);

// ─── ProgressBar ───────────────────────────────────────────────────────────────
interface ProgressBarProps {
  value: number;
  label: string;
  animated?: boolean;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  value,
  label,
  animated = false,
}) => (
  <div className="group">
    <div className="flex justify-between items-center mb-1.5">
      <span className="text-sm font-medium text-[var(--text)]">{label}</span>
      <span className="text-xs font-mono text-[var(--text-muted)]">{value}%</span>
    </div>
    <div className="h-px bg-[var(--border)] w-full overflow-hidden">
      <div
        className="h-full bg-[var(--gold)] transition-all duration-1000 ease-out"
        style={{ width: animated ? `${value}%` : "0%", transitionDelay: "200ms" }}
        data-value={value}
      />
    </div>
  </div>
);
