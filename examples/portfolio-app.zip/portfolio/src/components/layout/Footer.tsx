import React from "react";
import { GitFork, Link, Link2, Mail } from "lucide-react";
import { personalInfo, socialLinks } from "../../data";

const iconMap: Record<string, React.ReactNode> = {
  github: <GitFork size={16} />,
  linkedin: <Link size={16} />,
  twitter: <Link2 size={16} />,
  mail: <Mail size={16} />,
};

const Footer: React.FC = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-[var(--border)] py-10 px-6">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="text-center md:text-left">
          <p className="font-display font-bold text-[var(--text)] text-lg" style={{ fontFamily: "'Playfair Display', serif" }}>
            {personalInfo.name}
          </p>
          <p className="text-xs text-[var(--text-muted)] mt-1 font-mono">
            © {year} — Built with React & TypeScript
          </p>
        </div>

        <div className="flex items-center gap-4">
          {socialLinks.map((link) => (
            <a
              key={link.platform}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={link.platform}
              className="p-2 text-[var(--text-muted)] hover:text-[var(--gold)] transition-colors duration-200"
            >
              {iconMap[link.icon]}
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
