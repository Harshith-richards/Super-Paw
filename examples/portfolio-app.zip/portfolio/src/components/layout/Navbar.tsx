import React, { useState, useEffect } from "react";
import { Sun, Moon, Menu, X, Download } from "lucide-react";
import { navItems, personalInfo } from "../../data";
import { useScrollSpy } from "../../hooks";

interface NavbarProps {
  isDark: boolean;
  onToggleTheme: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ isDark, onToggleTheme }) => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const sectionIds = navItems.map((item) => item.href.replace("#", ""));
  const activeId = useScrollSpy(sectionIds);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-[var(--bg)]/90 backdrop-blur-md border-b border-[var(--border)]"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                handleNavClick("#home");
              }}
              className="font-display text-lg font-bold text-[var(--text)] tracking-tight hover:text-[var(--gold)] transition-colors"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              AM
              <span className="text-[var(--gold)]">.</span>
            </a>

            {/* Desktop nav */}
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map((item) => {
                const id = item.href.replace("#", "");
                const isActive = activeId === id;
                return (
                  <a
                    key={item.href}
                    href={item.href}
                    onClick={(e) => {
                      e.preventDefault();
                      handleNavClick(item.href);
                    }}
                    className={`px-4 py-2 text-sm font-medium tracking-wide transition-colors duration-200 relative group ${
                      isActive
                        ? "text-[var(--text)]"
                        : "text-[var(--text-muted)] hover:text-[var(--text)]"
                    }`}
                  >
                    {item.label}
                    <span
                      className={`absolute bottom-1 left-4 right-4 h-px bg-[var(--gold)] transition-transform duration-200 origin-left ${
                        isActive ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100"
                      }`}
                    />
                  </a>
                );
              })}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-2">
              {personalInfo.resumeUrl && (
                <a
                  href={personalInfo.resumeUrl}
                  download
                  className="hidden md:inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-mono tracking-wider border border-[var(--border)] text-[var(--text-muted)] hover:border-[var(--gold)] hover:text-[var(--text)] transition-all duration-200"
                >
                  <Download size={12} />
                  Resume
                </a>
              )}
              <button
                onClick={onToggleTheme}
                className="p-2 text-[var(--text-muted)] hover:text-[var(--text)] transition-colors"
                aria-label="Toggle theme"
              >
                {isDark ? <Sun size={16} /> : <Moon size={16} />}
              </button>
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="md:hidden p-2 text-[var(--text-muted)] hover:text-[var(--text)] transition-colors"
                aria-label="Toggle menu"
              >
                {menuOpen ? <X size={18} /> : <Menu size={18} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <div
        className={`fixed inset-0 z-40 bg-[var(--bg)] transition-transform duration-300 md:hidden ${
          menuOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex flex-col items-center justify-center h-full gap-8">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={(e) => {
                e.preventDefault();
                handleNavClick(item.href);
              }}
              className="font-display text-3xl font-bold text-[var(--text)] hover:text-[var(--gold)] transition-colors"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              {item.label}
            </a>
          ))}
          {personalInfo.resumeUrl && (
            <a
              href={personalInfo.resumeUrl}
              download
              className="mt-4 flex items-center gap-2 px-6 py-2.5 border border-[var(--border)] text-sm text-[var(--text-muted)] hover:border-[var(--gold)] transition-colors"
            >
              <Download size={14} />
              Download Resume
            </a>
          )}
        </div>
      </div>
    </>
  );
};

export default Navbar;
