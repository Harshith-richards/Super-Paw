import React, { useEffect, useRef } from "react";
import { Monitor, Server, Cloud, Wrench } from "lucide-react";
import { skillCategories } from "../../data";
import { SectionHeader } from "../ui";
import { useInView } from "../../hooks";

const iconMap: Record<string, React.ReactNode> = {
  monitor: <Monitor size={18} />,
  server: <Server size={18} />,
  cloud: <Cloud size={18} />,
  wrench: <Wrench size={18} />,
};

const SkillsSection: React.FC = () => {
  const { ref, inView } = useInView();
  const barsRef = useRef<HTMLDivElement>(null);

  // Animate bars when in view
  useEffect(() => {
    if (!inView || !barsRef.current) return;
    const bars = barsRef.current.querySelectorAll("[data-value]");
    bars.forEach((bar) => {
      const value = bar.getAttribute("data-value");
      if (value) {
        setTimeout(() => {
          (bar as HTMLElement).style.width = `${value}%`;
        }, 100);
      }
    });
  }, [inView]);

  return (
    <section id="skills" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div
          ref={ref}
          className={`transition-all duration-700 ${
            inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <SectionHeader
            number="02 — Skills"
            title="Tools of the Trade"
            subtitle="Technologies I work with daily, rated by proficiency and comfort."
          />

          <div ref={barsRef} className="grid md:grid-cols-2 gap-8">
            {skillCategories.map((category, catIdx) => (
              <div
                key={category.id}
                className="p-6 border border-[var(--border)] hover:border-[var(--gold)] transition-all duration-300"
                style={{ transitionDelay: `${catIdx * 100}ms` }}
              >
                {/* Category header */}
                <div className="flex items-center gap-3 mb-6 pb-4 border-b border-[var(--border)]">
                  <span className="text-[var(--gold)]">{iconMap[category.icon]}</span>
                  <h3 className="font-mono text-xs tracking-[0.2em] uppercase text-[var(--text)] font-medium">
                    {category.label}
                  </h3>
                </div>

                {/* Skills list */}
                <div className="space-y-5">
                  {category.skills.map((skill, skillIdx) => (
                    <div key={skill.name}>
                      <div className="flex justify-between items-center mb-1.5">
                        <span className="text-sm text-[var(--text)]">{skill.name}</span>
                        <span className="font-mono text-xs text-[var(--text-muted)]">
                          {skill.level}%
                        </span>
                      </div>
                      <div className="h-px bg-[var(--border)] w-full overflow-hidden">
                        <div
                          data-value={skill.level}
                          className="h-full bg-[var(--gold)] transition-all ease-out"
                          style={{
                            width: "0%",
                            transitionDuration: "800ms",
                            transitionDelay: `${catIdx * 150 + skillIdx * 60}ms`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Additional tags */}
          <div className="mt-12 pt-8 border-t border-[var(--border)]">
            <p className="font-mono text-xs tracking-widest uppercase text-[var(--text-muted)] mb-4">
              Also familiar with
            </p>
            <div className="flex flex-wrap gap-2">
              {[
                "Prisma", "tRPC", "Zod", "Zustand", "SWR", "Playwright", "Turborepo",
                "Nx", "Terraform", "MongoDB", "Supabase", "PlanetScale", "Stripe API",
                "Sanity CMS", "Three.js"
              ].map((tag) => (
                <span
                  key={tag}
                  className="px-3 py-1 text-xs font-mono bg-[var(--bg-alt)] border border-[var(--border)] text-[var(--text-muted)] hover:border-[var(--gold)] hover:text-[var(--text)] transition-colors cursor-default"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
