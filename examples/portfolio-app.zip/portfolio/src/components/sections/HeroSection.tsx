import React, { useEffect } from "react";
import { ArrowDown, GitFork, Link, Mail, Download } from "lucide-react";
import { personalInfo, socialLinks } from "../../data";

const iconMap: Record<string, React.ReactNode> = {
  github: <GitFork size={15} />,
  linkedin: <Link size={15} />,
  twitter: null,
  mail: <Mail size={15} />,
};

const HeroSection: React.FC = () => {
  useEffect(() => {
    const els = document.querySelectorAll("[data-hero]");
    els.forEach((el, i) => {
      setTimeout(() => {
        (el as HTMLElement).style.opacity = "1";
        (el as HTMLElement).style.transform = "translateY(0)";
      }, 150 + i * 120);
    });
  }, []);

  const heroStyle: React.CSSProperties = {
    opacity: 0,
    transform: "translateY(20px)",
    transition: "opacity 0.7s ease, transform 0.7s ease",
  };

  return (
    <section
      id="home"
      className="min-h-screen flex flex-col justify-center relative overflow-hidden px-6 pt-16"
    >
      {/* Background glow */}
      <div
        aria-hidden
        className="absolute top-1/4 right-0 w-96 h-96 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(212,168,64,0.07) 0%, transparent 70%)" }}
      />
      <div
        aria-hidden
        className="absolute bottom-1/4 left-0 w-64 h-64 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(212,168,64,0.05) 0%, transparent 70%)" }}
      />

      <div className="max-w-6xl mx-auto w-full grid md:grid-cols-2 gap-12 items-center py-20">
        {/* Text */}
        <div>
          <p data-hero style={heroStyle} className="font-mono text-xs tracking-[0.3em] uppercase text-[var(--gold)] mb-5">
            Available for opportunities
          </p>

          <h1
            data-hero
            style={{
              ...heroStyle,
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2.75rem, 6vw, 4.5rem)",
              lineHeight: 1.05,
              fontWeight: 900,
            }}
            className="text-[var(--text)] mb-6"
          >
            {personalInfo.name}
          </h1>

          <p data-hero style={heroStyle} className="font-mono text-sm tracking-wider text-[var(--gold)] mb-6 uppercase">
            {personalInfo.role}
          </p>

          <p data-hero style={heroStyle} className="text-[var(--text-muted)] leading-relaxed max-w-md mb-10 text-base">
            {personalInfo.tagline}
          </p>

          {/* CTAs */}
          <div data-hero style={heroStyle} className="flex flex-wrap gap-3 mb-10">
            <a
              href="#projects"
              onClick={(e) => { e.preventDefault(); document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" }); }}
              className="inline-flex items-center gap-2 px-7 py-3 bg-[var(--text)] text-[var(--bg)] text-sm font-medium tracking-wide hover:bg-[var(--gold)] transition-colors duration-200"
            >
              View Work
            </a>
            <a
              href="#contact"
              onClick={(e) => { e.preventDefault(); document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" }); }}
              className="inline-flex items-center gap-2 px-7 py-3 border border-[var(--border)] text-[var(--text)] text-sm font-medium tracking-wide hover:border-[var(--gold)] hover:text-[var(--gold)] transition-colors duration-200"
            >
              Get in Touch
            </a>
            {personalInfo.resumeUrl && (
              <a
                href={personalInfo.resumeUrl}
                download
                className="inline-flex items-center gap-2 px-5 py-3 text-[var(--text-muted)] text-sm hover:text-[var(--text)] transition-colors duration-200"
              >
                <Download size={14} />
                Resume
              </a>
            )}
          </div>

          {/* Social links */}
          <div data-hero style={heroStyle} className="flex items-center gap-4">
            {socialLinks
              .filter((s) => iconMap[s.icon])
              .map((link) => (
                <a
                  key={link.platform}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={link.platform}
                  className="p-2 text-[var(--text-muted)] hover:text-[var(--gold)] border border-transparent hover:border-[var(--border)] transition-all duration-200"
                >
                  {iconMap[link.icon]}
                </a>
              ))}
          </div>
        </div>

        {/* Avatar side */}
        <div data-hero style={heroStyle} className="hidden md:flex justify-center items-center">
          <div className="relative">
            <div className="absolute -inset-3 border border-[var(--gold)] opacity-25" />
            <div className="absolute -inset-6 border border-[var(--border)] opacity-15" />
            <div className="relative w-64 h-64 overflow-hidden bg-[var(--bg-alt)] border border-[var(--border)] flex items-center justify-center">
              <img
                src={personalInfo.avatar}
                alt={personalInfo.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-4 -right-4 bg-[var(--bg)] border border-[var(--border)] px-4 py-2.5">
              <p className="font-mono text-xs text-[var(--text-muted)] tracking-wider">
                📍 {personalInfo.location}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
        <ArrowDown size={14} className="text-[var(--text-muted)]" />
        <span className="font-mono text-xs text-[var(--text-muted)] tracking-widest uppercase">scroll</span>
      </div>
    </section>
  );
};

export default HeroSection;
