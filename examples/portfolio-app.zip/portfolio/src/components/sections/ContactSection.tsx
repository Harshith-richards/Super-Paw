import React, { useState } from "react";
import { Send, GitFork, Link, Link2, Mail, CheckCircle, AlertCircle } from "lucide-react";
import { personalInfo, socialLinks } from "../../data";
import { SectionHeader } from "../ui";
import { useInView, useFormValidation } from "../../hooks";
import type { ContactForm } from "../../types";

const iconMap: Record<string, React.ReactNode> = {
  github: <GitFork size={16} />,
  linkedin: <Link size={16} />,
  twitter: <Link2 size={16} />,
  mail: <Mail size={16} />,
};

const initialForm: ContactForm = {
  name: "",
  email: "",
  subject: "",
  message: "",
};

type SubmitStatus = "idle" | "loading" | "success" | "error";

const ContactSection: React.FC = () => {
  const { ref, inView } = useInView();
  const { validate } = useFormValidation();

  const [form, setForm] = useState<ContactForm>(initialForm);
  const [errors, setErrors] = useState<Partial<ContactForm>>({});
  const [touched, setTouched] = useState<Partial<Record<keyof ContactForm, boolean>>>({});
  const [status, setStatus] = useState<SubmitStatus>("idle");

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (touched[name as keyof ContactForm]) {
      const newErrors = validate({ ...form, [name]: value });
      setErrors(newErrors);
    }
  };

  const handleBlur = (
    e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    const newErrors = validate(form);
    setErrors(newErrors);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setTouched({ name: true, email: true, subject: true, message: true });
    const newErrors = validate(form);
    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) return;

    setStatus("loading");
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setStatus("success");
    setForm(initialForm);
    setTouched({});
  };

  const inputBase =
    "w-full bg-transparent border border-[var(--border)] px-4 py-3 text-sm text-[var(--text)] placeholder:text-[var(--text-muted)] focus:outline-none focus:border-[var(--gold)] transition-colors duration-200 font-sans";
  const errorClass = "border-red-400 dark:border-red-600";

  return (
    <section id="contact" className="py-24 px-6 bg-[var(--bg-alt)]">
      <div className="max-w-6xl mx-auto">
        <div
          ref={ref}
          className={`transition-all duration-700 ${
            inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <SectionHeader
            number="05 — Contact"
            title="Let's Talk"
            subtitle="Have a project in mind, or just want to say hello? I'd love to hear from you."
          />

          <div className="grid md:grid-cols-2 gap-12 lg:gap-20">
            {/* Left — info */}
            <div className="space-y-8">
              <p className="text-[var(--text-muted)] leading-relaxed">
                I'm currently open to new opportunities — whether that's a full-time role,
                a consulting engagement, or an exciting side project collaboration.
                My inbox is always open.
              </p>

              <div className="space-y-4">
                <div className="flex items-center gap-3 text-sm">
                  <Mail size={14} className="text-[var(--gold)] flex-shrink-0" />
                  <a
                    href={`mailto:${personalInfo.email}`}
                    className="text-[var(--text)] hover:text-[var(--gold)] transition-colors"
                  >
                    {personalInfo.email}
                  </a>
                </div>
                {personalInfo.phone && (
                  <div className="flex items-center gap-3 text-sm">
                    <span className="text-[var(--gold)]">📞</span>
                    <span className="text-[var(--text)]">{personalInfo.phone}</span>
                  </div>
                )}
              </div>

              {/* Socials */}
              <div>
                <p className="font-mono text-xs tracking-widest uppercase text-[var(--text-muted)] mb-4">
                  Find me online
                </p>
                <div className="flex flex-wrap gap-3">
                  {socialLinks.map((link) => (
                    <a
                      key={link.platform}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2.5 border border-[var(--border)] text-sm text-[var(--text-muted)] hover:border-[var(--gold)] hover:text-[var(--text)] transition-all duration-200"
                    >
                      {iconMap[link.icon]}
                      {link.platform}
                    </a>
                  ))}
                </div>
              </div>

              {/* Response time */}
              <div className="p-4 border border-[var(--border)]">
                <p className="text-xs font-mono tracking-wider text-[var(--text-muted)]">
                  ⚡ Average response time: <span className="text-[var(--text)]">24–48 hours</span>
                </p>
              </div>
            </div>

            {/* Right — form */}
            <div>
              {status === "success" ? (
                <div className="flex flex-col items-center justify-center h-full gap-4 py-16 border border-[var(--gold)] border-opacity-40">
                  <CheckCircle size={40} className="text-[var(--gold)]" />
                  <p
                    className="font-bold text-xl text-[var(--text)] text-center"
                    style={{ fontFamily: "'Playfair Display', serif" }}
                  >
                    Message Sent!
                  </p>
                  <p className="text-sm text-[var(--text-muted)] text-center">
                    Thanks for reaching out. I'll get back to you soon.
                  </p>
                  <button
                    onClick={() => setStatus("idle")}
                    className="mt-2 text-xs font-mono tracking-wider text-[var(--gold)] hover:underline"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate className="space-y-4">
                  {/* Name */}
                  <div>
                    <label className="block font-mono text-xs tracking-widest uppercase text-[var(--text-muted)] mb-1.5">
                      Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="Your full name"
                      className={`${inputBase} ${touched.name && errors.name ? errorClass : ""}`}
                    />
                    {touched.name && errors.name && (
                      <p className="mt-1 text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle size={10} /> {errors.name}
                      </p>
                    )}
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block font-mono text-xs tracking-widest uppercase text-[var(--text-muted)] mb-1.5">
                      Email *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={form.email}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="you@example.com"
                      className={`${inputBase} ${touched.email && errors.email ? errorClass : ""}`}
                    />
                    {touched.email && errors.email && (
                      <p className="mt-1 text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle size={10} /> {errors.email}
                      </p>
                    )}
                  </div>

                  {/* Subject */}
                  <div>
                    <label className="block font-mono text-xs tracking-widest uppercase text-[var(--text-muted)] mb-1.5">
                      Subject *
                    </label>
                    <input
                      type="text"
                      name="subject"
                      value={form.subject}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      placeholder="What's this about?"
                      className={`${inputBase} ${touched.subject && errors.subject ? errorClass : ""}`}
                    />
                    {touched.subject && errors.subject && (
                      <p className="mt-1 text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle size={10} /> {errors.subject}
                      </p>
                    )}
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block font-mono text-xs tracking-widest uppercase text-[var(--text-muted)] mb-1.5">
                      Message *
                    </label>
                    <textarea
                      name="message"
                      value={form.message}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      rows={5}
                      placeholder="Tell me about your project or just say hi..."
                      className={`${inputBase} resize-none ${touched.message && errors.message ? errorClass : ""}`}
                    />
                    {touched.message && errors.message && (
                      <p className="mt-1 text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle size={10} /> {errors.message}
                      </p>
                    )}
                  </div>

                  {/* Submit */}
                  <button
                    type="submit"
                    disabled={status === "loading"}
                    className="w-full flex items-center justify-center gap-2 px-6 py-3.5 bg-[var(--text)] text-[var(--bg)] text-sm font-medium tracking-wide hover:bg-[var(--gold)] transition-colors duration-200 disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {status === "loading" ? (
                      <>
                        <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                        </svg>
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send size={14} />
                        Send Message
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
