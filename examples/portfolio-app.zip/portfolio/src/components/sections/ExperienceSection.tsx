import React, { useState } from "react";
import { Briefcase, GraduationCap, MapPin } from "lucide-react";
import { experiences } from "../../data";
import { SectionHeader, Badge } from "../ui";
import { useInView } from "../../hooks";
import type { Experience } from "../../types";

interface TimelineItemProps {
  exp: Experience;
  index: number;
  inView: boolean;
}

const TimelineItem: React.FC<TimelineItemProps> = ({ exp, index, inView }) => {
  const isWork = exp.type === "work";

  return (
    <div
      className={`relative pl-8 pb-10 last:pb-0 transition-all duration-700`}
      style={{
        opacity: inView ? 1 : 0,
        transform: inView ? "translateX(0)" : "translateX(-16px)",
        transitionDelay: `${index * 100}ms`,
      }}
    >
      {/* Timeline line */}
      <div className="absolute left-0 top-0 bottom-0 w-px bg-[var(--border)]" />

      {/* Timeline dot */}
      <div
        className={`absolute left-0 top-1 -translate-x-1/2 w-3 h-3 border-2 ${
          isWork
            ? "bg-[var(--gold)] border-[var(--gold)]"
            : "bg-[var(--bg)] border-[var(--gold)]"
        }`}
      />

      {/* Content card */}
      <div className="ml-6 p-5 border border-[var(--border)] bg-[var(--bg)] hover:border-[var(--gold)] transition-colors duration-300 group">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[var(--gold)]">
                {isWork ? <Briefcase size={13} /> : <GraduationCap size={13} />}
              </span>
              <span className="font-mono text-xs tracking-widest uppercase text-[var(--text-muted)]">
                {isWork ? "Work" : "Education"}
              </span>
            </div>
            <h3
              className="font-bold text-lg text-[var(--text)] group-hover:text-[var(--gold)] transition-colors"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              {exp.title}
            </h3>
            <p className="text-sm font-medium text-[var(--text-muted)] mt-0.5">
              {exp.organization}
            </p>
          </div>

          <div className="flex flex-col items-start sm:items-end gap-1 flex-shrink-0">
            <span className="font-mono text-xs text-[var(--text-muted)] whitespace-nowrap">
              {exp.startDate} — {exp.endDate}
            </span>
            <span className="flex items-center gap-1 font-mono text-xs text-[var(--text-muted)]">
              <MapPin size={10} />
              {exp.location}
            </span>
          </div>
        </div>

        {/* Description */}
        <ul className="space-y-1.5 mb-4">
          {exp.description.map((desc, i) => (
            <li key={i} className="text-sm text-[var(--text-muted)] leading-relaxed flex gap-2">
              <span className="text-[var(--gold)] mt-1.5 flex-shrink-0">—</span>
              {desc}
            </li>
          ))}
        </ul>

        {/* Tech stack */}
        {exp.technologies && exp.technologies.length > 0 && (
          <div className="flex flex-wrap gap-1.5 pt-3 border-t border-[var(--border)]">
            {exp.technologies.map((tech) => (
              <Badge key={tech}>{tech}</Badge>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const ExperienceSection: React.FC = () => {
  const { ref, inView } = useInView();
  const [filter, setFilter] = useState<"all" | "work" | "education">("all");

  const filtered = experiences.filter(
    (e) => filter === "all" || e.type === filter
  );

  return (
    <section id="experience" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div
          ref={ref}
          className={`transition-all duration-700 ${
            inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <SectionHeader
            number="04 — Experience"
            title="Career Timeline"
            subtitle="Where I've worked and studied, in reverse chronological order."
          />

          {/* Filter tabs */}
          <div className="flex gap-1 mb-10 border-b border-[var(--border)] pb-0">
            {(["all", "work", "education"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setFilter(tab)}
                className={`px-5 py-2.5 text-xs font-mono tracking-widest uppercase transition-all border-b-2 -mb-px ${
                  filter === tab
                    ? "border-[var(--gold)] text-[var(--text)]"
                    : "border-transparent text-[var(--text-muted)] hover:text-[var(--text)]"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Timeline */}
          <div className="max-w-3xl">
            {filtered.map((exp, i) => (
              <TimelineItem key={exp.id} exp={exp} index={i} inView={inView} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;
