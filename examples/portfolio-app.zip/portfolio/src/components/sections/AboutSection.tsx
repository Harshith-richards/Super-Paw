import React from "react";
import { MapPin, Mail, Calendar, Award } from "lucide-react";
import { personalInfo } from "../../data";
import { SectionHeader } from "../ui";
import { useInView } from "../../hooks";

const stats = [
  { label: "Years Experience", value: "6+" },
  { label: "Projects Shipped", value: "40+" },
  { label: "Open Source PRs", value: "120+" },
  { label: "Cups of Coffee", value: "∞" },
];

const AboutSection: React.FC = () => {
  const { ref, inView } = useInView();

  return (
    <section id="about" className="py-24 px-6 bg-[var(--bg-alt)]">
      <div className="max-w-6xl mx-auto">
        <div
          ref={ref}
          className={`transition-all duration-700 ${
            inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <SectionHeader
            number="01 — About"
            title="A Little About Me"
            subtitle="Engineer, builder, occasional over-thinker."
          />

          <div className="grid md:grid-cols-2 gap-12 lg:gap-20">
            {/* Bio */}
            <div className="space-y-5">
              <p className="text-[var(--text)] leading-relaxed text-base">
                {personalInfo.bio}
              </p>
              <p className="text-[var(--text-muted)] leading-relaxed text-base">
                When I'm not pushing commits, you'll find me reading about systems design,
                cycling through city backstreets, or hunting for the perfect cup of single-origin
                pour-over. I care deeply about craft — whether that's in code, writing, or espresso.
              </p>
              <p className="text-[var(--text-muted)] leading-relaxed text-base">
                I thrive in environments where design and engineering overlap, and I believe
                the best products are built by people who can hold both dimensions simultaneously.
              </p>

              {/* Contact details */}
              <div className="pt-4 space-y-3">
                {[
                  { icon: <MapPin size={14} />, text: personalInfo.location },
                  { icon: <Mail size={14} />, text: personalInfo.email },
                  { icon: <Calendar size={14} />, text: "Open to full-time & contract roles" },
                  { icon: <Award size={14} />, text: "UC Berkeley — B.S. Computer Science" },
                ].map(({ icon, text }) => (
                  <div key={text} className="flex items-center gap-3 text-sm text-[var(--text-muted)]">
                    <span className="text-[var(--gold)]">{icon}</span>
                    {text}
                  </div>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div>
              <div className="grid grid-cols-2 gap-4">
                {stats.map((stat, i) => (
                  <div
                    key={stat.label}
                    className="p-6 border border-[var(--border)] hover:border-[var(--gold)] transition-colors duration-300"
                    style={{ transitionDelay: `${i * 80}ms` }}
                  >
                    <p
                      className="font-bold text-4xl text-[var(--text)] mb-1"
                      style={{ fontFamily: "'Playfair Display', serif" }}
                    >
                      {stat.value}
                    </p>
                    <p className="text-xs font-mono tracking-wider text-[var(--text-muted)] uppercase">
                      {stat.label}
                    </p>
                  </div>
                ))}
              </div>

              {/* Current status */}
              <div className="mt-6 p-5 border border-[var(--gold)] border-opacity-40 bg-[var(--bg)]">
                <div className="flex items-center gap-2 mb-2">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500" />
                  </span>
                  <span className="font-mono text-xs tracking-widest uppercase text-[var(--text-muted)]">
                    Currently at
                  </span>
                </div>
                <p className="text-sm font-medium text-[var(--text)]">Senior Frontend Engineer</p>
                <p className="text-xs text-[var(--text-muted)] font-mono mt-0.5">Linear — Jan 2023 to Present</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
