import React, { useState } from "react";
import { ExternalLink, GitFork, Star } from "lucide-react";
import { projects } from "../../data";
import { SectionHeader, Badge } from "../ui";
import { useInView } from "../../hooks";

const ProjectsSection: React.FC = () => {
  const { ref, inView } = useInView();
  const [showAll, setShowAll] = useState(false);

  const displayed = showAll ? projects : projects.filter((p) => p.featured);

  return (
    <section id="projects" className="py-24 px-6 bg-[var(--bg-alt)]">
      <div className="max-w-6xl mx-auto">
        <div
          ref={ref}
          className={`transition-all duration-700 ${
            inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <SectionHeader
            number="03 — Projects"
            title="Selected Work"
            subtitle="A curated selection of projects I've built, shipped, and maintained."
          />

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {displayed.map((project, i) => (
              <article
                key={project.id}
                className="group flex flex-col border border-[var(--border)] bg-[var(--bg)] hover:border-[var(--gold)] transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                {/* Top bar */}
                <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-[var(--border)]">
                  <div className="flex items-center gap-2">
                    {project.featured && (
                      <Star size={11} className="text-[var(--gold)] fill-[var(--gold)]" />
                    )}
                    <span className="font-mono text-xs text-[var(--text-muted)] tracking-wider">
                      {project.year}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {project.githubUrl && (
                      <a
                        href={project.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[var(--text-muted)] hover:text-[var(--text)] transition-colors"
                        aria-label="GitHub"
                      >
                        <GitFork size={14} />
                      </a>
                    )}
                    {project.liveUrl && (
                      <a
                        href={project.liveUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[var(--text-muted)] hover:text-[var(--gold)] transition-colors"
                        aria-label="Live demo"
                      >
                        <ExternalLink size={14} />
                      </a>
                    )}
                  </div>
                </div>

                {/* Body */}
                <div className="flex flex-col flex-1 p-5">
                  <h3
                    className="font-bold text-lg text-[var(--text)] mb-2 group-hover:text-[var(--gold)] transition-colors"
                    style={{ fontFamily: "'Playfair Display', serif" }}
                  >
                    {project.title}
                  </h3>
                  <p className="text-sm text-[var(--text-muted)] leading-relaxed mb-5 flex-1">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-1.5 mt-auto">
                    {project.techStack.map((tech) => (
                      <Badge key={tech}>{tech}</Badge>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>

          {/* Toggle */}
          {projects.length > displayed.length || showAll ? (
            <div className="mt-10 text-center">
              <button
                onClick={() => setShowAll(!showAll)}
                className="inline-flex items-center gap-2 px-6 py-2.5 border border-[var(--border)] text-sm text-[var(--text-muted)] hover:border-[var(--gold)] hover:text-[var(--text)] transition-all font-mono tracking-wider"
              >
                {showAll ? "Show Featured Only" : `View All Projects (${projects.length})`}
              </button>
            </div>
          ) : null}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
