import { useState, useEffect, useCallback } from "react";

// ─── useTheme ──────────────────────────────────────────────────────────────────
export function useTheme() {
  const [isDark, setIsDark] = useState<boolean>(() => {
    const saved = localStorage.getItem("theme");
    if (saved) return saved === "dark";
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      root.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [isDark]);

  const toggle = useCallback(() => setIsDark((d) => !d), []);

  return { isDark, toggle };
}

// ─── useScrollSpy ──────────────────────────────────────────────────────────────
export function useScrollSpy(sectionIds: string[], offset = 80) {
  const [activeId, setActiveId] = useState<string>("");

  useEffect(() => {
    const handleScroll = () => {
      for (let i = sectionIds.length - 1; i >= 0; i--) {
        const el = document.getElementById(sectionIds[i]);
        if (el && el.getBoundingClientRect().top <= offset) {
          setActiveId(sectionIds[i]);
          return;
        }
      }
      setActiveId("");
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, [sectionIds, offset]);

  return activeId;
}

// ─── useInView ─────────────────────────────────────────────────────────────────
export function useInView(threshold = 0.15) {
  const [ref, setRef] = useState<Element | null>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    if (!ref) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          observer.disconnect();
        }
      },
      { threshold }
    );
    observer.observe(ref);
    return () => observer.disconnect();
  }, [ref, threshold]);

  return { ref: setRef, inView };
}

// ─── useFormValidation ─────────────────────────────────────────────────────────
interface FormErrors {
  name?: string;
  email?: string;
  subject?: string;
  message?: string;
}

export function useFormValidation() {
  const validate = (values: {
    name: string;
    email: string;
    subject: string;
    message: string;
  }): FormErrors => {
    const errors: FormErrors = {};
    if (!values.name.trim()) errors.name = "Name is required";
    if (!values.email.trim()) {
      errors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
      errors.email = "Please enter a valid email";
    }
    if (!values.subject.trim()) errors.subject = "Subject is required";
    if (!values.message.trim()) {
      errors.message = "Message is required";
    } else if (values.message.trim().length < 20) {
      errors.message = "Message must be at least 20 characters";
    }
    return errors;
  };

  return { validate };
}
